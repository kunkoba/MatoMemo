@echo off
cd /d "%~dp0"

:: ====================================================================
:: �y�ݒ�G���A�z���O�������t�H���_�E�t�@�C�����𔼊p�X�y�[�X��؂�Ŏw��
:: ====================================================================
set "EXCLUDES=.git node_modules .vscode old *.tmp desktop.ini *.dll"
:: ====================================================================

echo �t�H���_�\������͒��i�t�@�C���D��E�C���f���g�Ȃ�JSON���[�h�j...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$root = '%~dp0'.TrimEnd('\'); " ^
    "$outFile = '%~dp0output_result.json'; " ^
    "$userExList = '%EXCLUDES%'.Split(' '); " ^
    "$excludePatterns = @('output_result.json', '%~nx0') + $userExList; " ^
    "function Get-DirectoryTree ($folderPath) { " ^
        "$items = @(Get-ChildItem -LiteralPath $folderPath -ErrorAction SilentlyContinue | Where-Object { " ^
            "$item = $_; " ^
            "$skip = $false; " ^
            "foreach ($pat in $script:excludePatterns) { " ^
                "if ($pat -ne '' -and $item.Name -like $pat) { $skip = $true; break } " ^
            "} " ^
            "-not $skip " ^
        "}); " ^
        "$dict = [ordered]@{}; " ^
        "foreach ($item in ($items | Where-Object { -not $_.PSIsContainer })) { " ^
            "$dict[$item.Name] = $null; " ^
        "} " ^
        "foreach ($item in ($items | Where-Object { $_.PSIsContainer })) { " ^
            "$dict[$item.Name] = (Get-DirectoryTree -folderPath $item.FullName); " ^
        "} " ^
        "return $dict " ^
    "}; " ^
    "$rootName = (Split-Path $root -Leaf); " ^
    "$tree = [ordered]@{ $rootName = (Get-DirectoryTree -folderPath $root) }; " ^
    "$json = $tree | ConvertTo-Json -Depth 100 -Compress; " ^
    "[System.IO.File]::WriteAllText($outFile, $json, [System.Text.Encoding]::UTF8)"

echo �������܂����I "%~dp0output_result.json" �ɕۑ�����܂����B
pause
